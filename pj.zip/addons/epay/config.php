<?php

return array(
    0 =>
        array(
            'name' => 'wechat',
            'title' => '微信',
            'type' => 'array',
            'content' =>
                array(),
            'value' =>
                array(
                    'appid' => 'wx61f9fds307ec7fd5c',
                    'app_id' => 'wx61f9fds307ec7fd5c',
                    'miniapp_id' => 'wxb3fxxxxxxxxxxx',
                    'mch_id' => '1480000000',
                    'key' => 'T8sFJghxSKVxPdc35UP9KQqzbkXBcwBq',
                    'notify_url' => '/addons/epay/api/notifyx/type/wechat',
                    'cert_client' => '/epay/certs/apiclient_cert.pem',
                    'cert_key' => '/epay/certs/apiclient_key.pem',
                    'log' => 1,
                ),
            'rule' => '',
            'msg' => '',
            'tip' => '微信参数配置',
            'ok' => '',
            'extend' => '',
        ),
    1 =>
        array(
            'name' => 'alipay',
            'title' => '支付宝',
            'type' => 'array',
            'content' =>
                array(),
            'value' =>
                array(
                    'app_id' => '2019021763232751',
                    'notify_url' => '/addons/epay/api/notifyx/type/alipay',
                    'return_url' => '/addons/epay/api/returnx/type/alipay',
                    'ali_public_key' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAisfo+ukVl59u94UlfWa6p7BvkDxNGyfwmLa/vS84gLABL5qSMHyPxzYb3mvuM55YYSMbdLeBJksQpgX6rpji/lpKCGarFRfSt6mWpofR0K/rrQF4fIh77NpBRiFbja2Qb++41VQXGw45m2ve2XCrCeLEC0JsTPue4n314eMpdtTvV5syJ/XqmuwgOWYaZo43cLsX788vlIglfywuMuOscOochIETQKYmmrzhbhrA60JLDOfAYxh92h99+/LwZoCUpA/wCXXzm9JerKFjkuzPcHbySa4IxU38OUsHlPB6JjnQjJ/CewK7MAySgEYljMSL3jpknjTwHttALW1g1MCWvQIDAQAB',
                    'private_key' => 'MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCKx+j66RWXn273hSV9ZrqnsG+QPE0bJ/CYtr+9LziAsAEvmpIwfI/HNhvea+4znlhhIxt0t4EmSxCmBfqumOL+WkoIZqsVF9K3qZamh9HQr+utAXh8iHvs2kFGIVuNrZBv77jVVBcbDjmba97ZcKsJ4sQLQmxM+57iffXh4yl21O9XmzIn9eqa7CA5Zhpmjjdwuxfvzy+UiCV/LC4y46xw6hyEgRNApiaavOFuGsDrQksM58BjGH3aH3378vBmgJSkD/AJdfOb0l6soWOS7M9wdvJJrgjFTfw5SweU8HomOdCMn8J7ArswDJKARiWMxIveOmSeNPAe20AtbWDUwJa9AgMBAAECggEASXSGXEgCpb49fcV7kmRNZ3R7mFxSc40wS6Ru2DOmNHb0Kb4mooNLlqWNGq0F50xoewGaBq0aLqqMpVOE2+UQQJCJnui4pPF3Fr8sffhllY+HroqYu1GCRls/MV92lgbH7Hd13XQkxq1A0ILH8U8xOIpOOaduq1CDSF5jRqx1xe8lh4nI7ORMa0dSlW58U0W6JJdx2G9pqI1Dq+4YuoBVcXtHdBkCTTQt3NDaOkitWfYjgJJWlUvPyllb+JCAqenn6slIXpBHc9HbBjN7aQ1m8cT/JTzZwiBWkHzy8AEx0E00AldQzQCBMSUOZaLtbcdvCGQnjt1Lk7TxA17WMzRCAQKBgQDWpF/IzgHO0FCe405N3ZLKDL6AfRtk/Rr/L8o/nsdFTuWu2k5HIpM5vCBNNl1WFtDZma3iur8sdHu7DKnOr/M7nxH7Xf7uHcD72JRFy6S9+GU2fYzpAIpT/OzEmB/qK7Rp/525fM1cQWvlYDFtTKDAbRewWrRcgDXVW9lCux56TwKBgQClhYorEsVl1NpXFlI8dovcExbgThZ95eY18nCKJWbpmWRcyKjzCdWPOU62JJbd0kq7M4mEkWxo2YcjoQYcjwj3GHdwH/J9bsRJnhlihvr2FI6J5D9cO9VsXNCJ+hF+X5sYgKTYjEAhKdu4YdemLc0ligb0mHwhbYVDrCXgkJT3MwKBgQDDlLHm4rhJAA6GSS8/ymeIDobDw7vjkLI51w0eXYrMP7EQW8G6Feo7UI3KbYAtAss5jEwi7fFnC5j2/vn36OHk8PRMrQCvbpM7qMSquH4b0CxBs7NjWOey0iPYm5lxInPZpl7M9siViNNNBhLjulA8JuvP+Uahhv4GtRPKN4D1BwKBgQCgTb+tzaUt5UJ8m1qTwj/bqQU7wYTY84HMd3t035pW3L8teQzfLIQPDPJlRvRx6ouD1/r0UB8NQLc302hm2kRVgvWRuu8PeepSXfK50H5XOzt84nhWrIAbTZyONIkiuhcsWNLOAq7NL4vje6buA2euVoo78z4s5bPuAVhBr+UFrwKBgBL/YU1Q1Ju5CEbSHGZORfCt2VoyirCxFHaI4YI5n77HqCir6E5zFBVBwJhO8Fz1KIb64h/y4LfRLU7j4cILQXgJj4mV4ZF3apojpzKK0N0fNZfWxPDc2nCkkurI1tK/j22oPh8dCwDWJHwUI4skXQwrvbK1WkQ4ZKvK1LRxr+C2',
                    'log' => '1',
//                    'mode' => 'dev',
                ),
            'rule' => 'required',
            'msg' => '',
            'tip' => '支付宝参数配置',
            'ok' => '',
            'extend' => '',
        ),
    2 =>
        array(
            'name' => '__tips__',
            'title' => '温馨提示',
            'type' => 'array',
            'content' =>
                array(),
            'value' => '请注意微信支付证书路径位于/addons/epay/certs目录下，请替换成你自己的证书<br>微信:mch_id为微信商户ID,appid为APP的appid,app_id为公众号的appid,miniapp_id为小程序ID,key为微信商户支付的密钥',
            'rule' => '',
            'msg' => '',
            'tip' => '微信参数配置',
            'ok' => '',
            'extend' => '',
        ),
);
