<?php

namespace Yansongda\Supports;

class Config extends Collection
{
}
