<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"D:\laragon\www\demo\public/../application/index\view\index\zhifu.html";i:1560217257;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo __('HttpTitle'); ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/assets/addons/epay/css/common.css" rel="stylesheet">

    <!-- Plugin CSS -->
    <link href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.staticfile.org/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo addon_url('epay/index/index'); ?>">FastAdmin</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                </li>
                <?php if($user): ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">欢迎你! <?php echo $user['nickname']; ?><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo url('index/user/index'); ?>">会员中心</a>
                        </li>
                        <li>
                            <a href="<?php echo url('index/user/profile'); ?>">个人资料</a>
                        </li>
                        <li>
                            <a href="<?php echo url('index/user/logout'); ?>">退出登录</a>
                        </li>
                    </ul>
                </li>
                <?php else: ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">会员中心 <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo url('index/user/register'); ?>">注册</a>
                        </li>
                        <li>
                            <a href="<?php echo url('index/user/login'); ?>">登录</a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>

<!-- Page Content -->
<div class="container">

    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">
                开始体验
            </h2>
        </div>
        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4><i class="fa fa-fw fa-compass"></i> 立即体验</h4>
                </div>
                <div class="panel-body">
                    <p>请选择对应的支付金额和支付方式</p>
                    <p>
                        <span class="input-group">
                            <input type="number" name="amount" step="2" value="<?php echo mt_rand(1, 99)/100; ?>"
                                   class="form-control" placeholder="请输入一个随机金额"/>
                            <span class="input-group-addon" style="padding:0;width:100px;">
                                <select class="form-control" name="method" id="method" style="border:none;height: 32px;">
                                    <option value="web">PC网页支付</option>
                                    <option value="wap">H5手机网页支付</option>
                                    <option value="app">APP支付</option>
                                    <option value="scan">扫码支付</option>
                                    <option value="mp">公众号支付(不支持支付宝)</option>
                                    <option value="miniapp">小程序支付(不支持支付宝)</option>
                                </select>
                            </span>
                        </span>
                    </p>
                    <button data-type="alipay" class="btn btn-info btn-experience"><i class="fa fa-money"></i> 支付宝支付</button>
                    <button data-type="wechat" class="btn btn-success btn-experience"><i class="fa fa-wechat"></i> 微信支付</button>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->

    <!-- /.row -->

    <hr>

    <!-- Call to Action Section -->
    <div class="well">
        <div class="row">
            <div class="col-md-8">
                <p>感谢你对***支付的支持！</p>
            </div>
            <!--<div class="col-md-4">
                <a class="btn btn-lg btn-default btn-block" href="https://forum.fastadmin.net"
                   target="_blank">立即前往社区</a>
            </div>-->
        </div>
    </div>

    <hr>

</div>

<div class="container">
    <!-- Footer -->
    <footer>
        <div class="row">
            <div class="col-lg-12">
                <hr>
                <p>Copyright &copy; <a href="/">***支付</a> 2017-1019</p>
            </div>
        </div>
    </footer>

</div>
<!-- /.container -->

<!-- jQuery -->
<script src="https://cdn.staticfile.org/jquery/2.1.4/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>


<script src="/assets/addons/epay/js/common.js"></script>

</body>

</html>
