<?php
//000000000000
 exit();?>
a:3:{s:8:"app_init";a:1:{i:0;s:17:"\addons\epay\Epay";}s:13:"response_send";a:1:{i:0;s:33:"\addons\loginbgindex\Loginbgindex";}s:16:"index_login_init";a:1:{i:0;s:33:"\addons\loginbgindex\Loginbgindex";}}